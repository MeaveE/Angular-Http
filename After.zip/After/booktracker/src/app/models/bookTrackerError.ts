export class BookTrackerError {
  errorNumber: number;
  message: string;
  friendlyMessage: string;
}