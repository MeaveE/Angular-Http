export class Reader {
    readerID: number;
    name: string;
    weeklyReadingGoal: number;
    totalMinutesRead: number;
}
